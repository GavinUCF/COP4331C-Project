<?php

	$con = mysqli_connect('localhost', 'root', 'root', 'unityaccess');
	
	// check that connection happened
	if(mysqli_connect_errno())
	{
		echo "1: Connection failed";
		exit();
	}

	$username = $_POST["name"];
	$password = $_POST["password"];

	// check if name already exists
	$namecheckquery = "SELECT username FROM player WHERE username='" . $username . "';";

	$namecheck = mysqli_query($con, $namecheckquery) or die("2: Name check query failed");

	if(mysqli_num_rows($namecheck) > 0)
	{
		echo "3: Name already exists";
		exit();
	}

	// add user to the table
	$salt = "\$5\$rounds=5000\$" . "steamtrains" . $username . "\$";
	$hash = crypt($password, $salt);
	$insertuserquery = "INSERT INTO player (username, hash, salt) VALUES ('" . $username . "', '" . $hash . "', '" . $salt . "');";
	mysqli_query($con, $insertuserquery) or die("4: Intsert player query failed");

	echo "0";


?>