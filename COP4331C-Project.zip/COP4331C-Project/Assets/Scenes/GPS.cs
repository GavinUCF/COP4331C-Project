﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GPS : MonoBehaviour {

	public static GPS Instance { set; get; }

	public float latitude;
	public float longitude;
	public float last_lat;
	public float last_long;

	private void Start()
	{
		Instance = this;
		DontDestroyOnLoad(gameObject);
		StartCoroutine(StartLocationService());
	}

	private IEnumerator StartLocationService()
	{
		if(!Input.location.isEnabledByUser)
		{
			Debug.Log("User has not enabled GPS");
			yield break;
		}

		Input.location.Start();
		int maxWait = 20;
		while(Input.location.status == LocationServiceStatus.Initializing && maxWait > 0)
		{
			yield return new WaitForSeconds(1);
			maxWait--;
		}

		if(maxWait <= 0)
		{
			Debug.Log("Timed out");
			yield break;
		}

		if(Input.location.status == LocationServiceStatus.Failed)
		{
			Debug.Log("Unable to determine device location.");
			yield break;
		}

		if(latitude == 0 && longitude == 0)
		{
			latitude = Input.location.lastData.latitude;
			longitude = Input.location.lastData.longitude;
		}
		else
		{
			last_lat = latitude;
			last_long = longitude;
			latitude = Input.location.lastData.latitude;
			longitude = Input.location.lastData.longitude;
			Calculate_Distance(last_long, last_lat, longitude, latitude);
		}
		
		yield break;
	}

	float DegToRad(float deg)
    {
        float temp;
        temp = (float)((deg * 3.1416) / 180.0f);
        temp = Mathf.Tan(temp);
        return temp;
    }
 
	float Distance_x(float lon_a, float lon_b, float lat_a, float lat_b)
     {
         float temp;
         float c;
         temp = (lat_b - lat_a);
         c = Mathf.Abs(temp * Mathf.Cos((lat_a + lat_b)) / 2);
         return c;
     }
 
     private float Distance_y(float lat_a, float lat_b)
     {
         float c;
         c = (lat_b - lat_a);
         return c;
     }
 
     float Final_distance(float x, float y)
     {
         float c;
         c = Mathf.Abs(Mathf.Sqrt(Mathf.Pow(x, 2f) + Mathf.Pow(y, 2f))) * 6371;
         return c;
     }
 
     //*******************************
 //This is the function to call to calculate the distance between two points
 
     public void Calculate_Distance(float long_a, float lat_a,float long_b, float lat_b )
     {
         float a_long_r, a_lat_r, p_long_r, p_lat_r, dist_x, dist_y, total_dist;
         a_long_r =DegToRad(long_a);
         a_lat_r = DegToRad(lat_a);
         p_long_r = DegToRad(long_b);
         p_lat_r = DegToRad(lat_b);
         dist_x = Distance_x(a_long_r, p_long_r, a_lat_r, p_lat_r);
         dist_y = Distance_y(a_lat_r, p_lat_r);
         total_dist = Final_distance(dist_x, dist_y);
     //prints the distance on the console
        DBManager.distance += (int)total_dist;
        if(DBManager.distance >= 1000)
		{
			DBManager.food = DBManager.distance / 1000;
		}
     }
}
